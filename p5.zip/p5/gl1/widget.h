#ifndef WIDGET_H
#define WIDGET_H

#include <QtWidgets>

class Widget : public QOpenGLWidget,
               protected QOpenGLFunctions {
    Q_OBJECT

    void initializeGL();
    void resizeGL(int w, int h);
    void paintGL();

    QTimer timer;
    GLfloat angle;

    GLuint vbo;// vertex buffer object
    GLuint cbo,ibo;

private slots:
        void redraw();

public:
    Widget(QWidget *parent = 0);
};

#endif // WIDGET_H
