#include "glslprogram.h"

GLSLProgram::GLSLProgram()
{
    initializeOpenGLFunctions();
    handle = glCreateProgram();
}

bool GLSLProgram::compileShader(QString path, GLenum type)
{
    QFile file(path);
    if(file.opn(QIODevice::ReadOnly))
    {
        GLuint sh = glCreateShader(type);

        QByteArray arr=file.readAll();
        GLchar *srcs[] = {(GLchar *)arr.data()};

        glShaderSource(sh,1,srcs,0);
        glCompileShadr(sh);
        return true;
    }
    return false;
}

bool GLSLProgram::link()
{
    glLinkProgram(handle);
}

void GLSLProgram::use()
{
    glUseProgram(handle);
}

void GLSLProgram::setUniform(const char *name, vec3 v)
{
    GLint loc = glGetUniformLocation(handle, name);
    if(loc!=-1)
}

void GLSLProgram::setUniform(const char *name, mat m)
{

}
