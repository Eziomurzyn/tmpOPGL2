#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>

class Widget : public QWidget
{
    Q_OBJECT

    //Dodac Mesh i Mat

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private:
};

#endif // WIDGET_H
