#ifndef GLSLPROGRAM_H
#define GLSLPROGRAM_H
#include<QOpenGLFunctions_3_3_Core>
#include<GL/gl.h>
#include<QtCore>

#include "matrix.h"

class GLSLProgram: protected QOpenGLFunctions_3_3_Core {
    GLuint handle;


public:
    GLSLProgram();
    bool compileShader(QString path, GLenum type);
    bool link();
    void use();
    void setUniform(const char *name,vec3 v);
    void setUniform(const char *name,mat m);
};

#endif // GLSLPROGRAM_H
