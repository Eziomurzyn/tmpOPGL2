#ifndef MESH_H
#define MESH_H


class mesh
{
public:
    mesh();
};

#endif // MESH_H